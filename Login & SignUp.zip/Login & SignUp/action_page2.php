<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "db1";
//Assuming you have established a connection to your database already
$conn = new mysqli($servername, $username, $password , $database);
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve values from the form
    $email = $_POST['email'];
    $pass = $_POST['psw'];

    // Perform a database query to check if the user exists
    $query = "SELECT * FROM info WHERE Email = '$email' AND Password = '$pass'";
    $result = $conn->query($query) ;

    // Check if the query returned any rows
    if (mysqli_num_rows($result) > 0) {
        // User exists, show a success message
        echo "User exists.";
    } else {
        // User does not exist, show an error message
        echo "User does not exist.";
    }
}
?>