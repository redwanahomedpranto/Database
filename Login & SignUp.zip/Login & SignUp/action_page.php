<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "db1";


if($_SERVER['REQUEST_METHOD']=='POST')
{
    $email = $_POST["email"];
    $pass = $_POST["psw"];
    $r_password = $_POST["psw-repeat"];


// Create connection
$conn = new mysqli($servername, $username, $password , $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
  echo " Unsuccessful..";
}

else if($pass === $r_password)
{
    echo "Connected Successfully";

    $sql = " insert into info
    values('$email','$pass','$r_password') ";

//    mysqli_error($conn,$sql);   
   
   if($conn->query($sql) === TRUE )
   {
     echo "Data inserted successfully";
   }
}

else{
    echo "Failed data insertion<br>";
    echo "Wrong input";
   }
    


}

?>